# Bài tập: Phối màu cho Newsletter

## Nội dung
- `newsletter_version1.html` + `style1.css`: phiên bản **Ocean Fresh** (xanh dương, xanh ngọc, nền sáng).
- `newsletter_version2.html` + `style2.css`: phiên bản **Sunset Studio** (tím mận, cam san hô, màu kem).
- Cả hai phiên bản dùng Bootstrap 5.3.3 qua CDN và có bố cục responsive.

## Cách chạy
1. Giải nén thư mục.
2. Mở `newsletter_version1.html` hoặc `newsletter_version2.html` trong trình duyệt.
3. Cần có Internet để tải Bootstrap từ CDN.

## Bảng màu
### Phiên bản 1 — Ocean Fresh
- Primary: `#176B87`
- Secondary: `#64CCC5`
- Accent: `#DAFFFB`
- Text: `#183B4E`
- Background: `#F4FBFC`

### Phiên bản 2 — Sunset Studio
- Primary: `#563A5C`
- Secondary: `#F08A5D`
- Accent: `#F9EDCC`
- Text: `#332638`
- Background: `#FFF9F2`

## Ghi chú
Các bảng màu được xây dựng theo cảm hứng phối màu tương phản hài hòa và cần được nhập/đối chiếu trên Adobe Color trước khi ghi rằng đã lưu trực tiếp từ Adobe Color. Nếu giảng viên yêu cầu minh chứng, hãy chụp màn hình palette trên Adobe Color.
