# CodeGym Career — Landing Page thực hành

Landing Page giới thiệu chương trình CodeGym Career, được xây dựng bằng HTML, CSS, JavaScript và Bootstrap Material Design (MDBootstrap 4.19.1).

## Tính năng
- Giao diện responsive cho máy tính, máy tính bảng và điện thoại.
- Thanh điều hướng, hero section, thẻ lợi ích, lộ trình học, khóa học, CTA và footer.
- Biểu mẫu tư vấn có kiểm tra trường bắt buộc và thông báo demo khi gửi.
- Sử dụng component và thư viện MDBootstrap qua CDN.

## Cách chạy
1. Tải hoặc giải nén thư mục dự án.
2. Mở `index.html` bằng trình duyệt.
3. Cần có kết nối Internet để tải Bootstrap, MDBootstrap, Google Fonts và Font Awesome từ CDN.

## Đưa lên GitHub
1. Tạo repository GitHub, ví dụ `Frontend`.
2. Trong repository, chọn **Add file → Upload files**.
3. Tải lên `index.html`, `style.css`, `script.js`, `README.md` (hoặc tải cả thư mục qua GitHub Desktop).
4. Chọn **Commit changes**.
5. Nếu muốn chạy website trực tiếp: vào **Settings → Pages**, chọn branch `main` và folder `/ (root)`, rồi lưu. Chờ GitHub Pages tạo đường dẫn website.

## Lưu ý
Đây là bài tập giao diện front-end. Biểu mẫu chưa kết nối máy chủ và không lưu dữ liệu. Nội dung chương trình mang tính tham khảo, hãy đối chiếu thông tin tuyển sinh hiện hành với CodeGym.

Nguồn nội dung tham khảo: https://codegym.vn/codegym-career/
