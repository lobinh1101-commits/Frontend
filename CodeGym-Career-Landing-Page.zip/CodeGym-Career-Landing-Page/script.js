document.addEventListener('DOMContentLoaded', function () {
  var year = document.getElementById('year');
  if (year) year.textContent = new Date().getFullYear();

  var form = document.getElementById('consultForm');
  var message = document.getElementById('formMessage');
  if (form && message) {
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!form.checkValidity()) {
        form.reportValidity();
        return;
      }
      var name = document.getElementById('fullname').value.trim();
      message.textContent = 'Cảm ơn ' + name + '! Biểu mẫu đã được kiểm tra thành công. Đây là bản demo nên thông tin chưa được gửi đến máy chủ.';
      message.className = 'form-message success';
      form.reset();
    });
  }

  // Đóng menu trên thiết bị di động sau khi chọn liên kết.
  var navLinks = document.querySelectorAll('#mainNav .nav-link, #mainNav .btn');
  navLinks.forEach(function (link) {
    link.addEventListener('click', function () {
      if (window.jQuery && window.innerWidth < 992) {
        window.jQuery('#mainNav').collapse('hide');
      }
    });
  });
});
